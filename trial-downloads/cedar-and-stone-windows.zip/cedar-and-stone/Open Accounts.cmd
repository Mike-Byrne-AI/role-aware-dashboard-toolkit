@echo off
setlocal DisableDelayedExpansion
title Cedar and Stone - Initial Accounts
wsl.exe --distribution Ubuntu-24.04 --cd "%~dp0." --exec bash scripts/start-wsl.sh accounts
if errorlevel 1 pause
