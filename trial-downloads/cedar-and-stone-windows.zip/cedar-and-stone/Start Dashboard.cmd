@echo off
setlocal DisableDelayedExpansion
title Cedar and Stone - Dashboard
where wsl.exe >nul 2>&1
if errorlevel 1 goto missing
wsl.exe --distribution Ubuntu-24.04 --exec true >nul 2>&1
if errorlevel 1 goto missing
wsl.exe --distribution Ubuntu-24.04 --cd "%~dp0." --exec bash scripts/start-wsl.sh
if errorlevel 1 (
  echo.
  echo The dashboard stopped with an error. Keep this window open to read it.
  pause
)
exit /b
:missing
echo This dashboard uses Ubuntu 24.04 through Windows WSL.
echo.
echo FIRST-TIME SETUP:
echo 1. Open Windows Terminal or PowerShell as Administrator.
echo 2. Run: wsl --install -d Ubuntu-24.04
echo 3. Restart Windows if asked. Open Ubuntu 24.04 and create its username/password.
echo 4. Double-click Start Dashboard.cmd again.
echo.
echo See WINDOWS-START-HERE.txt in this folder for the full instructions.
pause
exit /b 1
