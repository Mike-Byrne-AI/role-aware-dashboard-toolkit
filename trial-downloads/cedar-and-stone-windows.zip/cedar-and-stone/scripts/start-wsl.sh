#!/usr/bin/env bash
set -euo pipefail
umask 077
source_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
if [[ "${1:-launch}" == accounts ]]; then
    exec python3 "$source_dir/scripts/desktop_launch.py" --accounts
fi
if [[ "${1:-launch}" != launch ]]; then
    printf '%s\n' 'Unknown launcher action.' >&2
    exit 1
fi
if ! python3 -c 'import sys, venv, ensurepip; assert sys.version_info >= (3, 12)' >/dev/null 2>&1; then
    printf '%s\n' 'Installing Python inside Ubuntu. Enter your Ubuntu password if sudo asks.'
    sudo apt-get update
    sudo apt-get install -y python3 python3-venv ca-certificates
fi
python3 -c 'import sys, venv, ensurepip; assert sys.version_info >= (3, 12), "Ubuntu 24.04 with Python 3.12 or newer is required."'
exec python3 "$source_dir/scripts/desktop_launch.py"
