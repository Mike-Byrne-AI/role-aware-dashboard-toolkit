"""Private Linux/WSL installation and launch; never exports cloud credentials."""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import sqlite3
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import uuid

SOURCE = Path(__file__).resolve().parents[1]
DEFAULT_HOME = Path.home() / '.local' / 'share' / 'cedar-stone-trial'


def private_directory(path: Path) -> None:
    path.mkdir(parents=True, mode=0o700, exist_ok=True)
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise RuntimeError(f'Expected a private Linux-owned directory: {path}')


def source_files(source: Path):
    paths = [source / 'requirements.txt']
    for directory in ('landscape', 'vendor'):
        paths.extend(p for p in (source / directory).rglob('*')
                     if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc')
    if not (source / 'landscape/app.py').is_file():
        raise RuntimeError('Extract the complete ZIP before starting the dashboard.')
    return sorted(paths)


def install_release(source: Path, base: Path) -> tuple[Path, bool]:
    files = source_files(source)
    manifest = {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    version = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()[:24]
    releases = base / 'releases'
    private_directory(releases)
    destination = releases / version
    if destination.exists():
        private_directory(destination)
        for name, digest in manifest.items():
            p = destination / name
            if not p.is_file() or p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest() != digest:
                raise RuntimeError(f'Installed application was changed: {p}. No files were overwritten.')
        return destination, False
    with tempfile.TemporaryDirectory(prefix='.install-', dir=releases) as temporary:
        stage = Path(temporary) / 'app'
        private_directory(stage)
        for path in files:
            if path.is_symlink():
                raise RuntimeError('Source files must be regular files, not symbolic links.')
            target = stage / path.relative_to(source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
            target.chmod(0o600)
        stage.rename(destination)
    return destination, True


def backup_data(data: Path, base: Path) -> None:
    db = data / 'landscape.sqlite3'
    if not db.exists():
        return
    backups = base / 'backups'
    private_directory(backups)
    backup = backups / uuid.uuid4().hex
    private_directory(backup)
    for name in ('landscape.sqlite3', 'identity.key', 'TRIAL_ACCOUNTS.md'):
        path = data / name
        if path.is_symlink():
            raise RuntimeError('Refusing to back up a symbolic link in private storage.')
    with sqlite3.connect(db.as_uri() + '?mode=ro', uri=True) as original:
        with sqlite3.connect(backup / 'landscape.sqlite3') as copy:
            original.backup(copy)
    for name in ('identity.key', 'TRIAL_ACCOUNTS.md'):
        if (data / name).is_file():
            shutil.copyfile(data / name, backup / name)
    for path in backup.iterdir():
        path.chmod(0o600)
    print('Existing accounts and data were backed up privately before this version starts.', flush=True)


def needs_provisioning(data: Path) -> bool:
    database = data / 'landscape.sqlite3'
    if not database.exists():
        if any(data.iterdir()):
            raise RuntimeError('Existing data has no database. Nothing was reset; keep this folder for recovery.')
        return True
    if database.is_symlink():
        raise RuntimeError('The private database must not be a symbolic link.')
    with sqlite3.connect(database.as_uri() + '?mode=ro', uri=True) as connection:
        tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if 'users' in tables and connection.execute('SELECT COUNT(*) FROM users').fetchone()[0]:
            key = data / 'identity.key'
            if not key.is_file() or key.is_symlink():
                raise RuntimeError('Existing accounts are missing their original identity key. Nothing was reset; restore the private backup.')
            info = key.stat()
            if info.st_size != 32 or info.st_uid != os.getuid() or info.st_mode & 0o077:
                raise RuntimeError('The original identity key is invalid or not private. Nothing was reset; restore the private backup.')
            return False
        if (data / 'TRIAL_ACCOUNTS.md').exists():
            raise RuntimeError('Initial provisioning is incomplete: an account sheet exists without users. Nothing was reset; keep the data folder for recovery.')
        if any(table in tables and connection.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]
               for table in ('jobs', 'customers', 'messages')):
            raise RuntimeError('Existing business records have no accounts. Nothing was reset; keep the data folder for recovery.')
        if tables and 'users' not in tables:
            raise RuntimeError('Existing database schema is incomplete. Nothing was reset; keep the data folder for recovery.')
    # A canceled first seed can leave an empty schema. The seed transaction itself
    # refuses populated accounts or a handoff; resuming here never resets either.
    return True


def open_accounts(data: Path) -> None:
    path = data / 'TRIAL_ACCOUNTS.md'
    if not path.is_file() or path.is_symlink():
        raise RuntimeError('No initial account sheet exists yet. Run Start Dashboard first.')
    if not shutil.which('wslpath') or not shutil.which('notepad.exe'):
        print(f'Open the private initial account sheet: {path}', flush=True)
        return
    windows_path = subprocess.check_output(['wslpath', '-w', str(path)], text=True).strip()
    subprocess.Popen(['notepad.exe', windows_path], stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)


def verify_windows_connection(port: int, launch_id: str) -> None:
    if not shutil.which('powershell.exe'):
        raise RuntimeError('Windows integration is unavailable in Ubuntu. Enable WSL interoperability before using this launcher.')
    # The nonce is public, random readiness data, not a login credential. Reading it
    # from Windows distinguishes our server from a conflicting Windows listener.
    url = f'http://127.0.0.1:{port}/static/desktop-ready.txt'
    command = (
        "$ErrorActionPreference='Stop'; try { "
        f"$q=[Net.HttpWebRequest]::Create('{url}'); $q.Proxy=$null; $q.Timeout=10000; "
        "$r=$q.GetResponse(); $reader=New-Object IO.StreamReader($r.GetResponseStream()); "
        "$actual=$reader.ReadToEnd().Trim(); $reader.Dispose(); $r.Dispose(); "
        f"if ($actual -eq '{launch_id}') {{ exit 0 }} else {{ exit 2 }} "
        "} catch { exit 3 }"
    )
    try:
        result = subprocess.run(['powershell.exe', '-NoLogo', '-NoProfile', '-NonInteractive',
                                 '-Command', command], stdin=subprocess.DEVNULL,
                                capture_output=True, timeout=20)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError('Could not check the connection from Windows to Ubuntu.') from exc
    if result.returncode:
        raise RuntimeError(
            f'Windows could not reach this dashboard on port {port}. Another Windows app, '
            'WSL localhost forwarding, or VPN/firewall settings may be responsible. '
            'No browser or account sheet was opened; no unrelated process was stopped.'
        )


def open_browser(port: int) -> None:
    url = f'http://127.0.0.1:{port}/'
    if shutil.which('powershell.exe'):
        # Only a validated integer is inserted into this fixed command; no file paths or secrets.
        subprocess.Popen(['powershell.exe', '-NoLogo', '-NoProfile', '-NonInteractive',
                          '-Command', f"Start-Process '{url}'"], stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print(f'Open in your Windows browser: {url}', flush=True)


def wait_until_ready(server: subprocess.Popen, port: int, timeout=30) -> None:
    deadline = time.monotonic() + timeout
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    while time.monotonic() < deadline:
        if server.poll() is not None:
            raise RuntimeError('The dashboard server exited before it was ready. Read the error above.')
        try:
            with opener.open(f'http://127.0.0.1:{port}/', timeout=1) as response:
                body = response.read()
                if response.status == 200 and b'Cedar' in body and server.poll() is None:
                    return
        except (OSError, urllib.error.URLError):
            pass
        time.sleep(0.15)
    raise RuntimeError('The dashboard did not become ready. No unrelated process was stopped.')


def launch(base: Path, source: Path, port: int, no_browser: bool) -> None:
    if os.getuid() == 0:
        raise RuntimeError('Run as your ordinary Ubuntu user, not root or sudo.')
    # Unix permissions are mandatory; fail before installation on mounted Windows drives.
    private_directory(base)
    lock_fd = os.open(base / 'launcher.lock', os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    with os.fdopen(lock_fd, 'w') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError('Cedar & Stone is already starting or running. Use its existing window.') from exc
        # Reserve the actual listener before installation. Passing this exact socket to
        # the child eliminates port-check races and never connects to an unrelated app.
        with socket.socket() as listener:
            try:
                listener.bind(('127.0.0.1', port))
                listener.listen(128)
            except OSError as exc:
                raise RuntimeError(f'Port {port} is busy. Close the other app or use --port with another port.') from exc
            app, _ = install_release(source, base)
            python = app / '.venv/bin/python'
            env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PIP_DISABLE_PIP_VERSION_CHECK='1')
            ready = app / '.dependencies-ready'
            if not ready.exists():
                print('First start: installing dashboard dependencies. This needs Internet access.', flush=True)
                if not python.is_file():
                    subprocess.run([sys.executable, '-m', 'venv', str(app / '.venv')], check=True)
                subprocess.run([str(python), '-m', 'pip', 'install', '-r', 'requirements.txt'],
                               cwd=app, env=env, check=True)
                subprocess.run([str(python), '-m', 'pip', 'check'], cwd=app, env=env, check=True)
                ready.touch(mode=0o600)
            data = base / 'data'
            private_directory(data)
            fresh = needs_provisioning(data)
            active_path = base / 'active-release.txt'
            active_release = active_path.read_text().strip() if active_path.is_file() else None
            env['LANDSCAPE_DATA_DIR'] = str(data)
            if fresh:
                print('Creating six new fictional accounts. Passwords stay in a private local file.', flush=True)
                subprocess.run([str(python), '-m', 'landscape.seed', '--data-dir', str(data)],
                               cwd=app, env=env, check=True)
            elif active_release != app.name:
                backup_data(data, base)
            launch_id = uuid.uuid4().hex
            (app / 'landscape/static/desktop-ready.txt').write_text(launch_id + '\n')
            server = subprocess.Popen([str(python), '-m', 'uvicorn', 'landscape.app:app',
                                       '--fd', str(listener.fileno()), '--no-access-log', '--no-proxy-headers'],
                                      cwd=app, env=env, pass_fds=(listener.fileno(),), start_new_session=True,
                                      stdin=subprocess.DEVNULL)
            try:
                wait_until_ready(server, port)
                if not no_browser:
                    verify_windows_connection(port, launch_id)
                active_path.write_text(app.name + '\n')
                print('Dashboard ready. Leave this window open; Ctrl+C stops the server.', flush=True)
                print(f'Private accounts and saved work: {data}', flush=True)
                if not no_browser:
                    if fresh:
                        open_accounts(data)
                    open_browser(port)
                else:
                    print(f'Local test URL: http://127.0.0.1:{port}/', flush=True)
                code = server.wait()
                if code:
                    raise RuntimeError(f'The dashboard server stopped with exit code {code}.')
            finally:
                if server.poll() is None:
                    # Popen owns this child; no stored PID or process-name guessing.
                    server.send_signal(signal.SIGTERM)
                    try:
                        server.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        server.kill()
                        server.wait(timeout=5)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--home', type=Path, default=DEFAULT_HOME)
    parser.add_argument('--port', type=int, default=8088)
    parser.add_argument('--no-browser', action='store_true')
    parser.add_argument('--accounts', action='store_true')
    args = parser.parse_args()
    os.umask(0o077)
    if not 1024 <= args.port <= 65535:
        parser.error('Choose a port between 1024 and 65535.')
    try:
        base = args.home.expanduser().absolute()
        if args.accounts:
            open_accounts(base / 'data')
        else:
            launch(base, SOURCE, args.port, args.no_browser)
    except KeyboardInterrupt:
        print('\nDashboard stopped. Your accounts and work are saved.', flush=True)
    except (RuntimeError, OSError, sqlite3.Error, subprocess.SubprocessError) as exc:
        print(f'\nCould not start: {exc}', file=sys.stderr, flush=True)
        return 1
    return 0


def request_stop(signum, frame):
    raise KeyboardInterrupt


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGHUP, request_stop)
    raise SystemExit(main())
